# Super mario run
A fun super mario game made using html, css & JavaScript 

<img width="701" alt="image" src="https://user-images.githubusercontent.com/88031057/184356544-d9696f33-9bca-41cf-9ba4-e779c95ed592.png">

## Usage
  <a href="https://super-mario-run-by-varun-banka.netlify.app/">CLICK HERE</a>


<a href="https://www.buymeacoffee.com/bankavarunk" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>
